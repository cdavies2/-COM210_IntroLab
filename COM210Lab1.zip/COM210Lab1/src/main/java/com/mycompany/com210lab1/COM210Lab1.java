package com.mycompany.com210lab1;

import javax.swing.JOptionPane;

public class COM210Lab1 
{

    public static void main(String[] args) 
    {
        //algorithm one
      /*
        String[] items= new String[3];
        double[] prices=new double[3];
        double money=0;
        for(int i=0; i<3; i++)
        {
          String s=JOptionPane.showInputDialog("Please enter an item");
          items[i]=s;
          String t=JOptionPane.showInputDialog("Please enter the item's price");
          money=Double.parseDouble(t);
          prices[i]=money;
          System.out.println(items[i] + " " + prices[i]);
        }    
        double average;
        average=(prices[0] + prices[1] + prices[2])/3;
        System.out.println(average);
        
        
        //algorithm 2
        String[] items= new String[3];
        double[] prices=new double[3];
        double money=0;
        for(int i=0; i<3; i++)
        {
          String s=JOptionPane.showInputDialog("Please enter an item");
          items[i]=s;
          String t=JOptionPane.showInputDialog("Please enter the item's price");
          money=Double.parseDouble(t);
          prices[i]=money;
          System.out.println(items[i] + " " + prices[i]);
        }    
        double average;
        average=(prices[0] + prices[1] + prices[2])/3;
        
        if(items[0].equalsIgnoreCase("peas") || items[1].equalsIgnoreCase("peas") || items[2].equalsIgnoreCase("peas"))
        {
            System.out.println("The average price is $" + average);
        }  
        else
        {
            System.out.println("No average output");
        }    
        */
        //algoritm 3
        String s=JOptionPane.showInputDialog("Enter the number of items");
        int f=Integer.parseInt(s);
        String[] items=new String[f];
        double price[]=new double[f];
        
        for(int i=0; i<f; i++)
        {
          String p=JOptionPane.showInputDialog("Please enter an item");
          items[i]=p;
          String t=JOptionPane.showInputDialog("Please enter the item's price");
          double money=Double.parseDouble(t);
          price[i]=money;
          System.out.println(items[i] + " " + price[i]);
        }
        double average;
        average=(price[0] + price[1] + price[2])/3;
        
          if(items[0].equalsIgnoreCase("peas") || items[1].equalsIgnoreCase("peas") || items[2].equalsIgnoreCase("peas"))
        {
            System.out.println("The average price is $" + average);
        }  
        else
        {
            System.out.println("No average output");
        }
          
       for(int t=f-1; t>=0; t--)
       {
           System.out.println(items[t] + " $" + price[t] );
       }    
    }
}
