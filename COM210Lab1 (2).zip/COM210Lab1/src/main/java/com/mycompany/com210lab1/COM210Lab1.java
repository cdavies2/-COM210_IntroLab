package com.mycompany.com210lab1;

import javax.swing.JOptionPane;

public class COM210Lab1 
{

    public static void main(String[] args) 
    {
        //c1=assignment, c2=request for input, c3=print
        //algorithm one
      
        String[] items= new String[3]; //c1
        double[] prices=new double[3]; //c1
        double money=0; //c1
        for(int i=0; i<3; i++) //n=3
        {
          String s=JOptionPane.showInputDialog("Please enter an item"); //c2
          items[i]=s; //c1
          String t=JOptionPane.showInputDialog("Please enter the item's price"); //c2
          money=Double.parseDouble(t); //c1
          prices[i]=money;//c1
          System.out.println(items[i] + " " + prices[i]); //c3
        }    
        double average; //c1
        average=(prices[0] + prices[1] + prices[2])/3; //c1
        System.out.println(average); //c3
        
        
        //algorithm 2
        
        String[] items2= new String[3]; //c1
        double[] prices2=new double[3]; //c1
        double money2=0; //c1 
        for(int i=0; i<3; i++) //n=3
        {
          String s=JOptionPane.showInputDialog("Please enter an item"); //c2
          items2[i]=s; //c1
          String t=JOptionPane.showInputDialog("Please enter the item's price"); //c2
          money2=Double.parseDouble(t); //c1
          prices2[i]=money2; //c1
          System.out.println(items2[i] + " " + prices2[i]); //c3
        }    
        double average2; //c1
        average2=(prices2[0] + prices2[1] + prices2[2])/3; //c1
        
        if(items[0].equalsIgnoreCase("peas") || items[1].equalsIgnoreCase("peas") || items[2].equalsIgnoreCase("peas"))
        {
            System.out.println("The average price is $" + average2); //c3
        }  
        else
        {
            System.out.println("No average output"); //c3
        }    
        //when the algorithm runs, only one of these options will occur, so when calculating time complexity, only include one of the c3s
        
        //algoritm 3
        String s=JOptionPane.showInputDialog("Enter the number of items"); //c2
        int f=Integer.parseInt(s); //c1
        String[] items3=new String[f]; //c1
        double price3[]=new double[f]; //c1
        
        for(int i=0; i<f; i++) //n=the input value
        {
          String p=JOptionPane.showInputDialog("Please enter an item"); //c2
          items3[i]=p; //c1
          String t=JOptionPane.showInputDialog("Please enter the item's price"); //c2
          double money3=Double.parseDouble(t); //c1
          price3[i]=money3; //c1
          System.out.println(items3[i] + " " + price3[i]); //c3
        }
        double average3; //c1
        average3=(price3[0] + price3[1] + price3[2])/3;//c1
        
          if(items[0].equalsIgnoreCase("peas") || items[1].equalsIgnoreCase("peas") || items[2].equalsIgnoreCase("peas"))
        {
            System.out.println("The average price is $" + average3); //c3
        }  
        else
        {
            System.out.println("No average output"); //c3
        }
          //only one c3 is included in calculating time complexity
       for(int t=f-1; t>=0; t--) //n=the input value
       {
           System.out.println(items3[t] + " $" + price3[t] );
       }    
    }
}
